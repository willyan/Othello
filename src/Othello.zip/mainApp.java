
public class mainApp {
	public static void main(String[] args) {
		gui gui1=new gui();
	}
}
