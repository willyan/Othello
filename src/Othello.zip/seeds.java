
public enum seeds {
	BLACK,WHITE,EMPTY
}
